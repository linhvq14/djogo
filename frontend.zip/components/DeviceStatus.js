import { useEffect, useState } from 'react';
import io from 'socket.io-client';

export default function DeviceStatus({ deviceId }) {
  const [status, setStatus] = useState(null);

  useEffect(() => {
    const socket = io("http://localhost:5000");
    socket.emit('join', { deviceId });

    socket.on('status_update', (data) => {
      setStatus(data);
    });

    return () => socket.disconnect();
  }, [deviceId]);

  return status ? (
    <div>
      <h2>Device Status</h2>
      <p>Status: {status.status}</p>
      <p>CPU Usage: {status.cpu_usage}%</p>
      <p>RAM Usage: {status.ram_usage}%</p>
      <p>Disk Space: {status.disk_space} GB</p>
    </div>
  ) : <p>Loading status...</p>;
}
