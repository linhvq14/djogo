import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function Customer() {
  const router = useRouter();
  const { id } = router.query;
  const [devices, setDevices] = useState([]);

  useEffect(() => {
    if (id) {
      fetch(`${process.env.NEXT_PUBLIC_API_HOST}/customers/${id}/devices`)
        .then(res => res.json())
        .then(data => setDevices(data));
    }
  }, [id]);

  return (
    <div>
      <h1>Devices for Customer {id}</h1>
      <ul>
        {devices.map(device => (
          <li key={device.id}>
            <Link href={`/device/${device.id}`}>
              {device.device_name} ({device.device_ip})
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
