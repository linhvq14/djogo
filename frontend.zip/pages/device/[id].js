import { useRouter } from 'next/router';
import DeviceStatus from '../../components/DeviceStatus';

export default function DevicePage() {
  const router = useRouter();
  const { id } = router.query;

  return (
    <div>
      <h1>Device {id} Monitoring</h1>
      <DeviceStatus deviceId={id} />
    </div>
  );
}
