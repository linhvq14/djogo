import Link from 'next/link';
import { useEffect, useState } from 'react';

export default function Home() {
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    fetch(`${process.env.NEXT_PUBLIC_API_HOST}/customers`)
      .then(res => res.json())
      .then(data => setCustomers(data));
  }, []);

  return (
    <div>
      <h1>Customer Dashboard</h1>
      <ul>
        {customers.map(customer => (
          <li key={customer.id}>
            <Link href={`/customer/${customer.id}`}>
              {customer.name}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
